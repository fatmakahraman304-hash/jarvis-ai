/* JARVIS bridge for SweetHomeJS. GPL-2.0-or-later; corresponding source bundled. */
import { Home, HomeController, UserPreferences, HomeFileRecorder, Wall, Room, Level, DimensionLine, Label, HomePieceOfFurniture, HomeDoorOrWindow, HomeLight, readFurnitureCatalog } from '@sweethomejs/core';
import { Sh3dContainer } from '../../../packages/core/src/io/Sh3dContainer';

type Session = {home: Home; homeController: HomeController; preferences: UserPreferences};
let catalogPromise: Promise<any> | null = null;
export async function loadCatalog(preferences: UserPreferences) {
  catalogPromise ??= fetch(import.meta.env.BASE_URL+'catalog.sh3f').then(r=>{if(!r.ok)throw Error('Furniture catalog missing');return r.arrayBuffer();}).then(b=>readFurnitureCatalog(Sh3dContainer.open(new Uint8Array(b)) as any));
  const catalog = await catalogPromise;
  if (!catalog) throw Error('Furniture catalog could not be decoded');
  for (const cat of catalog.getCategories()) for(const piece of cat.getFurniture()) preferences.getFurnitureCatalog().add(cat,piece);
}
const num=(v:unknown, lo=-1000, hi=1000)=>{const n=Number(v);if(!Number.isFinite(n)||n<lo||n>hi)throw Error('Invalid measurement: '+v);return n;};
const cm=(v:unknown)=>num(v)*100;
const color=(v:any)=>typeof v==='string'?num(parseInt(v.replace('#',''),16),0,0xffffff):num(v,0,0xffffff);
const point=(p:any)=>[cm(p[0]),cm(p[1])];
const id=(o:any)=>o.getId();
const recorder=new HomeFileRecorder();
export function createJarvisBridge(get:()=>Session, replace:(h:Home)=>Promise<void>) {
  const undo: Uint8Array[]=[];const redo:Uint8Array[]=[];
  let busy=false;
  const catalog=():any[]=>get().preferences.getFurnitureCatalog().getCategories().flatMap(c=>c.getFurniture());
  function state(details=false) {
    const h=get().home;
    const rooms=h.getRooms().map(r=>({id:id(r),name:r.getName(),area_m2:Math.round(r.getArea())/10000,points:r.getPoints().map(p=>p.map(n=>Math.round(n)/100))}));
    const pieces=h.getFurniture();
    const collisions:any[]=[];
    // Rectangular footprint intersections are warnings; intentionally nested items may overlap.
    for(let i=0;i<pieces.length;i++) for(let j=i+1;j<pieces.length;j++) {
      const a=pieces[i]!,b=pieces[j]!;if(a.getLevel()!==b.getLevel()||a.isDoorOrWindow()||b.isDoorOrWindow())continue;
      if(Math.abs(a.getX()-b.getX())<(a.getWidth()+b.getWidth())/2-2 && Math.abs(a.getY()-b.getY())<(a.getDepth()+b.getDepth())/2-2 && Math.abs(a.getElevation()-b.getElevation())<Math.min(a.getHeight(),b.getHeight()))collisions.push([id(a),id(b)]);
      if(collisions.length>=30)break;
    }
    return {engine:'SweetHomeJS',units:'metres',verification:'native-model',name:h.getName(),view_3d:h.getCamera()===h.getObserverCamera()?'walk':'top',counts:{walls:h.getWalls().length,rooms:rooms.length,furniture:pieces.length,levels:h.getLevels().length},rooms,area_m2:rooms.reduce((s,r)=>s+r.area_m2,0),overlap_warnings:collisions,
      ...(details?{walls:h.getWalls().map(w=>({id:id(w),start:[w.getXStart()/100,w.getYStart()/100],end:[w.getXEnd()/100,w.getYEnd()/100],thickness:w.getThickness()/100})),furniture:pieces.map(p=>({id:id(p),name:p.getName(),x:p.getX()/100,y:p.getY()/100,width:p.getWidth()/100,depth:p.getDepth()/100,height:p.getHeight()/100,angle:p.getAngle()*180/Math.PI})),levels:h.getLevels().map(l=>({id:id(l),name:l.getName(),elevation:l.getElevation()/100}))}:{})};
  }
  const all=()=>[...get().home.getWalls(),...get().home.getRooms(),...get().home.getFurniture(),...get().home.getLabels(),...get().home.getDimensionLines(),...get().home.getLevels()];
  async function mutate(op:any) {
    const {home:h,homeController:controller}=get();
    switch(op.kind) {
      case 'new': {
        if((h.getWalls().length||h.getFurniture().length)&&op.replace!==true)throw Error('Existing project: use replace=true only for an explicit new project; current version is backed up.');
        const next=new Home();next.setName(String(op.name||'JARVIS Proje').slice(0,100));await replace(next);break;
      }
      case 'level': {const l=new Level(String(op.name||'Kat'),cm(op.elevation||0),cm(op.floor_thickness??.2),cm(op.height??2.8));h.addLevel(l);h.setSelectedLevel(l);break;}
      case 'select_level': {const l=h.getLevels().find(l=>id(l)===op.id||l.getName()===op.name);if(!l)throw Error('Level not found');h.setSelectedLevel(l);break;}
      case 'wall': {
        const a=point(op.start),b=point(op.end);if(Math.hypot(a[0]!-b[0]!,a[1]!-b[1]!)<5)throw Error('Wall shorter than 5 cm');
        const w=new Wall(a[0]!,a[1]!,b[0]!,b[1]!,cm(num(op.thickness??.16,.03,1)),cm(num(op.height??2.8,.1,20)));w.setLevel(h.getSelectedLevel());
        if(op.color!==undefined){w.setLeftSideColor(color(op.color));w.setRightSideColor(color(op.color));}h.addWall(w);break;
      }
      case 'room': {
        if(!Array.isArray(op.points)||op.points.length<3||op.points.length>200)throw Error('Room needs 3–200 points');
        const r=new Room(op.points.map(point));r.setName(String(op.name||'Oda'));r.setAreaVisible(true);r.setLevel(h.getSelectedLevel());if(op.color!==undefined)r.setFloorColor(color(op.color));h.addRoom(r);break;
      }
      case 'furniture': {
        const matches=catalog().filter(p=>op.catalog_id?p.getId()===op.catalog_id:(p.getName()||'').toLowerCase().includes(String(op.name||'').toLowerCase()));
        if(!op.catalog_id&&!op.name)throw Error('Catalog id or name required');
        const item=matches.find(p=>(p.getName()||'').toLowerCase()===String(op.name||'').toLowerCase())||matches[0];if(!item)throw Error('Catalog item not found. Read catalog first.');
        const p:any=item.isDoorOrWindow()?new HomeDoorOrWindow(item as any):(typeof (item as any).getLightSources==='function'?new HomeLight(item as any):new HomePieceOfFurniture(item));
        p.setX(cm(op.x));p.setY(cm(op.y));p.setAngle(num(op.angle??0,-360,360)*Math.PI/180);p.setLevel(h.getSelectedLevel());
        if(op.width!==undefined)p.setWidth(cm(num(op.width,.05,30)));if(op.depth!==undefined)p.setDepth(cm(num(op.depth,.02,30)));if(op.height!==undefined)p.setHeight(cm(num(op.height,.02,30)));if(op.elevation!==undefined)p.setElevation(cm(op.elevation));if(op.color!==undefined)p.setColor(color(op.color));if(op.label)p.setName(String(op.label));
        controller.getFurnitureController().addFurniture([p]);break;
      }
      case 'dimension': {const a=point(op.start),b=point(op.end);const d=new DimensionLine(a[0]!,a[1]!,b[0]!,b[1]!,cm(op.offset??.4));d.setLevel(h.getSelectedLevel());h.addDimensionLine(d);break;}
      case 'label': {const p=new Label(String(op.text).slice(0,200),cm(op.x),cm(op.y));p.setLevel(h.getSelectedLevel());h.addLabel(p);break;}
      case 'update': {
        const o:any=all().find(o=>id(o)===op.id);if(!o)throw Error('Object not found');
        const setters:any={x:['setX',cm],y:['setY',cm],width:['setWidth',(v:any)=>cm(num(v,.02,100))],depth:['setDepth',(v:any)=>cm(num(v,.02,100))],height:['setHeight',(v:any)=>cm(num(v,.02,100))],elevation:['setElevation',cm],thickness:['setThickness',cm],angle:['setAngle',(x:any)=>num(x,-360,360)*Math.PI/180],name:['setName',String],color:['setColor',color],floor_color:['setFloorColor',color],wall_color:['setLeftSideColor',color]};
        for(const [key,v]of Object.entries(op.values||{})){if(!setters[key])throw Error('Unsupported property '+key);const [fn,convert]=setters[key];if(typeof o[fn]!=='function')throw Error('Property not applicable: '+key);o[fn](convert(v));if(key==='wall_color')o.setRightSideColor(convert(v));}break;
      }
      case 'delete': {const o=all().find(o=>id(o)===op.id);if(!o)throw Error('Object not found');h.setSelectedItems([o as any]);controller.deleteSelection();break;}
      case 'camera': {if(op.mode==='walk')controller.getHomeController3D().viewFromObserver();else controller.getHomeController3D().viewFromTop();break;}
      default: throw Error('Unsupported architecture operation: '+op.kind);
    }
    get().home.setModified(true);
  }
  return {
    state,
    catalog:(query='')=>catalog().filter(p=>(p.getName()||'').toLowerCase().includes(query.toLowerCase())).map(p=>({id:p.getId(),name:p.getName(),width:p.getWidth()/100,depth:p.getDepth()/100,height:p.getHeight()/100,opening:p.isDoorOrWindow(),model:!!p.getModel()})),
    async save(){return recorder.writeHome(get().home);},
    async load(bytes:Uint8Array|number[]){await replace((await recorder.readHomeFromZip(new Uint8Array(bytes))).home);return state();},
    async run(command:any) {
      if(busy)throw Error('Designer is busy');busy=true;
      try{
        if(command.op==='state')return state(!!command.details);
        if(command.op==='catalog')return this.catalog(command.query||'');
        if(command.op==='undo'||command.op==='redo') {
          const from=command.op==='undo'?undo:redo,to=command.op==='undo'?redo:undo;
          const bytes=from.pop();if(!bytes)throw Error('History is empty');to.push(await recorder.writeHome(get().home));await replace((await recorder.readHomeFromZip(bytes)).home);get().home.setModified(true);return state();
        }
        if(command.op!=='apply')throw Error('Unknown command');
        if(!Array.isArray(command.operations)||!command.operations.length||command.operations.length>400)throw Error('1–400 operations required');
        const before=await recorder.writeHome(get().home);
        try{for(const op of command.operations)await mutate(op);}catch(e){await replace((await recorder.readHomeFromZip(before)).home);throw e;}
        undo.push(before);if(undo.length>20)undo.shift();redo.length=0;
        // Connect simple matching wall ends so corner joins are model topology, not pixel guesses.
        const ws=get().home.getWalls();for(const w of ws)for(const v of ws){if(w===v||w.getLevel()!==v.getLevel())continue;if(Math.hypot(w.getXEnd()-v.getXStart(),w.getYEnd()-v.getYStart())<.1){w.setWallAtEnd(v);v.setWallAtStart(w);}}
        if(command.operations.some((o:any)=>o.kind==='new'))get().homeController.getHomeController3D().viewFromTop();
        await new Promise<void>(r=>requestAnimationFrame(()=>r()));
        const view=(globalThis as any).__planView; const canvas=document.querySelector('.sh-plan canvas') as HTMLCanvasElement|null;
        if(view&&canvas){view.updatePlanBounds();view.fitHome(canvas.clientWidth,canvas.clientHeight);view.paint();}
        return state();
      }finally{busy=false;}
    },
    modified:()=>get().home.isModified(),saved:()=>get().home.setModified(false)
  };
}
