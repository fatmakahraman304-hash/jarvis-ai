/*
 * App.tsx
 *
 * Original SweetHomeJS code, Copyright (c) 2026 SweetHomeJS contributors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

import { useEffect, useRef, useState } from "react";
import type { ReactElement } from "react";
import { Home, UserPreferences, HomeController, HomeFileRecorder } from "@sweethomejs/core";
import { HomePane, HomeViewAdapter, WebContentManager } from "@sweethomejs/ui";
import "@sweethomejs/ui/theme.css";
import { createJarvisBridge, loadCatalog } from "./jarvisBridge";
import { devEvent } from "./devEvents";

/**
 * The SweetHomeJS app: creates a Home + HomeController and mounts the
 * HomePane (plan + 3D editor).
 */
const contentManager = new WebContentManager();

export function App(): ReactElement {
  const [session, setSession] = useState<Session | null>(null);
  const sessionRef = useRef<Session | null>(null);

  const replaceSession = (next: Session): void => {
    sessionRef.current = next;
    (globalThis as unknown as Record<string, unknown>).__homeController = next.homeController;
    devEvent("state.set", {
      path: "session",
      home: next.home.getName(),
      walls: next.home.getWalls().length,
      rooms: next.home.getRooms().length,
      furniture: next.home.getFurniture().length,
    });
    setSession(next);
  };

  const openHome = async (): Promise<void> => {
    const files = await contentManager.pickFile(".sh3d");
    if (files === null || files.length === 0) {
      return;
    }
    try {
      const result = await new HomeFileRecorder().readHomeFromZip(files[0]!.bytes);
      const next = await createSession(result.home);
      devEvent("request", { method: "OPEN", path: files[0]!.name, status: 200 });
      replaceSession(next);
    } catch (error) {
      devEvent("error", { where: "openHome", message: error instanceof Error ? error.message : String(error) });
      console.error("Failed to open home", error);
    }
  };

  const saveHome = async (): Promise<void> => {
    const current = sessionRef.current;
    if (current === null) {
      return;
    }
    const name = current.home.getName() ?? "home.sh3d";
    const bytes = await new HomeFileRecorder().writeHome(current.home);
    devEvent("request", { method: "SAVE", path: name, status: 200, bytes: bytes.length });
    await contentManager.saveFile(name, bytes, ".sh3d");
  };

  useEffect(() => {
    (globalThis as unknown as Record<string, unknown>).__devEvent = devEvent;
    void createSession(new Home()).then(async (s) => {
      sessionRef.current = s;
      setSession(s);
      (globalThis as any).jarvisDesigner = createJarvisBridge(() => sessionRef.current!, async (home) => replaceSession(await createSession(home)));
      // Debug hooks for e2e
      (globalThis as unknown as Record<string, unknown>).__homeController = s.homeController;
      (globalThis as unknown as Record<string, unknown>).__preferences = s.preferences;
      (globalThis as unknown as Record<string, unknown>).__contentManager = contentManager;
      // Photo hook for e2e: renders the current home from the observer camera
      (globalThis as unknown as Record<string, unknown>).__renderPhoto = async (
        width: number,
        height: number,
        quality: number,
      ): Promise<{ progress: number[]; pixels: Uint8ClampedArray }> => {
        const { ThreeJSPhotoRenderer, PhotoQuality } = await import("@sweethomejs/photo");
        const home = sessionRef.current?.home ?? s.home;
        const renderer = new ThreeJSPhotoRenderer(home, s.preferences, quality === 0 ? PhotoQuality.LOW : PhotoQuality.HIGH);
        const image = { width, height, data: new Uint8ClampedArray(width * height * 4) };
        const progress: number[] = [];
        await renderer.render(image, home.getObserverCamera(), null, {
          photoRenderingProgress: (p: number) => progress.push(p),
          photoRenderingEnded: () => {},
          photoRenderingCanceled: () => {},
          photoRenderingFailed: () => {},
        });
        renderer.dispose();
        return { progress, pixels: image.data };
      };
      // Video hook for e2e: renders frames along the observer-camera path
      (globalThis as unknown as Record<string, unknown>).__renderVideoFrames = async (
        frameCount: number,
      ): Promise<{ frames: number; colored: number }> => {
        const { renderVideoFrames } = await import("@sweethomejs/photo");
        const home = sessionRef.current?.home ?? s.home;
        const camera = home.getObserverCamera();
        const path = [
          new (await import("@sweethomejs/core")).Camera(camera.getX(), camera.getY(), camera.getZ(), camera.getYaw(), camera.getPitch(), camera.getFieldOfView(), 0),
          new (await import("@sweethomejs/core")).Camera(camera.getX() + 500, camera.getY(), camera.getZ(), camera.getYaw(), camera.getPitch(), camera.getFieldOfView(), 5000),
        ];
        const frames = await renderVideoFrames(home, s.preferences, path, {
          width: 160,
          height: 120,
          fps: 12,
          quality: 0,
        });
        let colored = 0;
        const last = frames[frames.length - 1];
        if (last !== undefined) {
          for (let i = 0; i < last.data.length; i += 4) {
            if (last.data[i]! < 250 || last.data[i + 1]! < 250 || last.data[i + 2]! < 250) colored++;
          }
        }
        return { frames: frames.length, colored };
      };
      const { IndexedDBStore, PreferencesStore } = await import("@sweethomejs/ui");
      const store = new IndexedDBStore();
      (globalThis as unknown as Record<string, unknown>).__preferencesStore = new PreferencesStore(store);
    });
    return () => {
      void session;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (session === null) {
    return <div data-testid="app-loading">Loading…</div>;
  }

  return (
    <HomePane
      home={session.home}
      preferences={session.preferences}
      homeController={session.homeController}
      onOpenHome={openHome}
      onSaveHome={saveHome}
    />
  );
}

interface Session {
  home: Home;
  preferences: UserPreferences;
  homeController: HomeController;
}

async function createSession(home: Home): Promise<Session> {
  // Load a fixture from ?file=<path> (relative to the server) if provided
  const fixtureParam = new URLSearchParams(location.search).get("file");
  if (home.getFurniture().length === 0 && home.getWalls().length === 0 && fixtureParam !== null) {
    try {
      const response = await fetch(fixtureParam);
      if (response.ok) {
        const bytes = new Uint8Array(await response.arrayBuffer());
        const result = await new HomeFileRecorder().readHomeFromZip(bytes);
        home = result.home;
      }
    } catch {
      // Fall back to the empty home
    }
  }
  if (home.getName() === null) {
    home.setName("Untitled");
  }
  const preferences = new UserPreferences();
  await loadCatalog(preferences);
  const homeViewAdapter = new HomeViewAdapter();
  const homeController = new HomeController(home, preferences, {
    createHomeView: () => homeViewAdapter,
    createFurnitureView: () => ({}) as never,
    createFurnitureCatalogView: () => ({}) as never,
    createPlanView: () => ({}) as never,
    createView3D: () => ({}) as never,
    createWizardView: () => ({}) as never,
    createBackgroundImageWizardStepsView: () => ({}) as never,
    createImportedFurnitureWizardStepsView: () => ({}) as never,
    createImportedTextureWizardStepsView: () => ({}) as never,
    createThreadedTaskView: () => ({}) as never,
    createUserPreferencesView: () => ({}) as never,
    createLevelView: () => ({}) as never,
    createHomeFurnitureView: () => ({}) as never,
    createWallView: () => ({}) as never,
    createRoomView: () => ({}) as never,
    createPolylineView: () => ({}) as never,
    createDimensionLineView: () => ({}) as never,
    createLabelView: () => ({}) as never,
    createCompassView: () => ({}) as never,
    createObserverCameraView: () => ({}) as never,
    createHome3DAttributesView: () => ({}) as never,
    createTextureChoiceView: () => ({}) as never,
    createBaseboardChoiceView: () => ({}) as never,
    createModelMaterialsView: () => ({}) as never,
    createPageSetupView: () => ({}) as never,
    createPrintPreviewView: () => ({}) as never,
    createPhotoView: () => ({}) as never,
    createPhotosView: () => ({}) as never,
    createVideoView: () => ({}) as never,
    createHelpView: () => ({}) as never,
  } as never);
  return { home, preferences, homeController };
}
